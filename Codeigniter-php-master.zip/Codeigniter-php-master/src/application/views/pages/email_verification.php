<!DOCTYPE html>
<html>
<body>
    <div class="container">
        <br>
        <h3>Complete Login Register System</h3>
        <br>

        <?php
        echo $message;
        ?>
    </div>

</body>


</html>