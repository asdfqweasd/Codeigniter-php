<div class="container">


<div class="status">
    <h1 class="error">Your transaction was canceled!</h1>
</div>



<a href="<?php echo base_url("products"); ?>" class = "btn-link"> Back to Product Page </a>
</div>